﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MUPLKTestForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MUPLKTestForm))
        Me.CmdReadData = New System.Windows.Forms.Button()
        Me.LVData = New System.Windows.Forms.ListView()
        Me.HdrName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.HdrValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PicLK = New System.Windows.Forms.PictureBox()
        Me.LblDescriptionLeft = New System.Windows.Forms.Label()
        Me.PicLogo = New System.Windows.Forms.PictureBox()
        Me.LblDescriptionRight = New System.Windows.Forms.Label()
        Me.LblHdr1 = New System.Windows.Forms.Label()
        Me.LblHdr2 = New System.Windows.Forms.Label()
        Me.CmdClose = New System.Windows.Forms.Button()
        Me.LblHdr3 = New System.Windows.Forms.Label()
        Me.LblFtr1 = New System.Windows.Forms.Label()
        CType(Me.PicLK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CmdReadData
        '
        Me.CmdReadData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.CmdReadData.Location = New System.Drawing.Point(514, 516)
        Me.CmdReadData.Name = "CmdReadData"
        Me.CmdReadData.Size = New System.Drawing.Size(128, 43)
        Me.CmdReadData.TabIndex = 0
        Me.CmdReadData.Text = "Iscitaj podatke"
        Me.CmdReadData.UseVisualStyleBackColor = True
        '
        'LVData
        '
        Me.LVData.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.LVData.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.HdrName, Me.HdrValue})
        Me.LVData.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LVData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.LVData.HideSelection = False
        Me.LVData.Location = New System.Drawing.Point(15, 174)
        Me.LVData.Name = "LVData"
        Me.LVData.Size = New System.Drawing.Size(508, 322)
        Me.LVData.TabIndex = 1
        Me.LVData.UseCompatibleStateImageBehavior = False
        Me.LVData.View = System.Windows.Forms.View.Details
        '
        'HdrName
        '
        Me.HdrName.Text = "Name"
        Me.HdrName.Width = 169
        '
        'HdrValue
        '
        Me.HdrValue.Text = "Value"
        Me.HdrValue.Width = 313
        '
        'PicLK
        '
        Me.PicLK.BackColor = System.Drawing.SystemColors.Window
        Me.PicLK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PicLK.Location = New System.Drawing.Point(538, 174)
        Me.PicLK.Name = "PicLK"
        Me.PicLK.Size = New System.Drawing.Size(242, 322)
        Me.PicLK.TabIndex = 2
        Me.PicLK.TabStop = False
        '
        'LblDescriptionLeft
        '
        Me.LblDescriptionLeft.AutoSize = True
        Me.LblDescriptionLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblDescriptionLeft.Location = New System.Drawing.Point(15, 154)
        Me.LblDescriptionLeft.Name = "LblDescriptionLeft"
        Me.LblDescriptionLeft.Size = New System.Drawing.Size(262, 17)
        Me.LblDescriptionLeft.TabIndex = 3
        Me.LblDescriptionLeft.Text = "Sadrzaj iscitanih podataka sa licne karte"
        '
        'PicLogo
        '
        Me.PicLogo.Image = CType(resources.GetObject("PicLogo.Image"), System.Drawing.Image)
        Me.PicLogo.Location = New System.Drawing.Point(15, 12)
        Me.PicLogo.Name = "PicLogo"
        Me.PicLogo.Size = New System.Drawing.Size(120, 131)
        Me.PicLogo.TabIndex = 4
        Me.PicLogo.TabStop = False
        '
        'LblDescriptionRight
        '
        Me.LblDescriptionRight.AutoSize = True
        Me.LblDescriptionRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblDescriptionRight.Location = New System.Drawing.Point(535, 154)
        Me.LblDescriptionRight.Name = "LblDescriptionRight"
        Me.LblDescriptionRight.Size = New System.Drawing.Size(186, 17)
        Me.LblDescriptionRight.TabIndex = 5
        Me.LblDescriptionRight.Text = "Slika preuzeta sa licne karte"
        '
        'LblHdr1
        '
        Me.LblHdr1.AutoSize = True
        Me.LblHdr1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblHdr1.Location = New System.Drawing.Point(142, 15)
        Me.LblHdr1.Name = "LblHdr1"
        Me.LblHdr1.Size = New System.Drawing.Size(326, 17)
        Me.LblHdr1.TabIndex = 7
        Me.LblHdr1.Text = "Republika Srbija - Ministarstvo unutrašnjih poslova"
        '
        'LblHdr2
        '
        Me.LblHdr2.AutoSize = True
        Me.LblHdr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblHdr2.Location = New System.Drawing.Point(140, 34)
        Me.LblHdr2.Name = "LblHdr2"
        Me.LblHdr2.Size = New System.Drawing.Size(284, 29)
        Me.LblHdr2.TabIndex = 8
        Me.LblHdr2.Text = "Biometrijska lična karta"
        '
        'CmdClose
        '
        Me.CmdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.CmdClose.Location = New System.Drawing.Point(652, 516)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.Size = New System.Drawing.Size(128, 43)
        Me.CmdClose.TabIndex = 9
        Me.CmdClose.Text = "Zatvori"
        Me.CmdClose.UseVisualStyleBackColor = True
        '
        'LblHdr3
        '
        Me.LblHdr3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblHdr3.Location = New System.Drawing.Point(142, 69)
        Me.LblHdr3.Name = "LblHdr3"
        Me.LblHdr3.Size = New System.Drawing.Size(606, 66)
        Me.LblHdr3.TabIndex = 10
        Me.LblHdr3.Text = resources.GetString("LblHdr3.Text")
        '
        'LblFtr1
        '
        Me.LblFtr1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.LblFtr1.Location = New System.Drawing.Point(15, 516)
        Me.LblFtr1.Name = "LblFtr1"
        Me.LblFtr1.Size = New System.Drawing.Size(483, 43)
        Me.LblFtr1.TabIndex = 11
        Me.LblFtr1.Text = resources.GetString("LblFtr1.Text")
        '
        'MUPLKTestForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(799, 581)
        Me.Controls.Add(Me.LblFtr1)
        Me.Controls.Add(Me.LblHdr3)
        Me.Controls.Add(Me.CmdClose)
        Me.Controls.Add(Me.LblHdr2)
        Me.Controls.Add(Me.LblHdr1)
        Me.Controls.Add(Me.LblDescriptionRight)
        Me.Controls.Add(Me.PicLogo)
        Me.Controls.Add(Me.LblDescriptionLeft)
        Me.Controls.Add(Me.PicLK)
        Me.Controls.Add(Me.LVData)
        Me.Controls.Add(Me.CmdReadData)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "MUPLKTestForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MUP LK CardReader Test Form"
        CType(Me.PicLK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CmdReadData As Button
    Friend WithEvents LVData As ListView
    Friend WithEvents HdrName As ColumnHeader
    Friend WithEvents HdrValue As ColumnHeader
    Friend WithEvents PicLK As PictureBox
    Friend WithEvents LblDescriptionLeft As Label
    Friend WithEvents PicLogo As PictureBox
    Friend WithEvents LblDescriptionRight As Label
    Friend WithEvents LblHdr1 As Label
    Friend WithEvents LblHdr2 As Label
    Friend WithEvents CmdClose As Button
    Friend WithEvents LblHdr3 As Label
    Friend WithEvents LblFtr1 As Label
End Class
