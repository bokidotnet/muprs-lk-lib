﻿' ---
' Primer iscitavanje podataka sa licne karte u VB.NET koristeci ActiveX DLL 'MUPLKLib.dll' koji je pisan u VB6
' ---
' Za pravilno iscitavanje podataka potrebno je sledece:
'   1. U projektu dodati referencu kao COM objekat 'MUPLKLib.dll' ili 
'      rucno odraditi registraciju iz commandne linije regsvr32 MUPLKLib.dll gde se nalazi file
'   2. Potrebno je da su fileovi CelikApi.dll i netsetpkcs11_*.dll sistemski vidljivi kako bi im ActiveX DLL 'MUPLKLib.dll' pristupao bez problema
'      Najbolje je da se exe/dll dot.net projekta i fileovi MUPLKLib.dll, CelikApi.dll i netsetpkcs11_x86.dll nalaze u istom direktorijumu/folderu.
' 
' NAPOMENE
' - ActiveX DLL 'MUPLKLib.dll' je napisan u Visual Basic 6.0 te tako samo podrzava x86 verziju CelikAPI i odgovarajuce ostale sistemske fileove koji prate CelikAPI kao na primer netsetpkcs11_*.dll.
' ---

Imports System.IO

Public Class MUPLKTestForm

    Private ClassName As String = ""
    Private Function LVAddItem(ByRef ThisGroup As ListViewGroup,
                               ByVal ThisItemName As String,
                               ByVal ThisItemValue As String) As ListViewItem

        Dim xItem As ListViewItem = New ListViewItem(ThisItemName, ThisGroup)

        xItem.SubItems.Add(ThisItemValue)

        Return xItem

    End Function
    Private Sub SyncFixedPersonalData(ByRef ThisListView As ListView,
                                      ByRef ThisFixedPersonalData As MUPLKLib.cMUPLKFixedPersonalData)

        Dim xGroup As ListViewGroup = New ListViewGroup("fpd", "Fixed Personal Data")

        ' Add Group of items
        ThisListView.Groups.Add(xGroup)

        ' Assign data and append items to ListView
        With ThisFixedPersonalData
            ThisListView.Items.Add(LVAddItem(xGroup, "Surname", .Surname))
            ThisListView.Items.Add(LVAddItem(xGroup, "Given Name", .GivenName))
            ThisListView.Items.Add(LVAddItem(xGroup, "Parent Given Name", .ParentGivenName))
            ThisListView.Items.Add(LVAddItem(xGroup, "Date Of Birth", .DateOfBirth))
            ThisListView.Items.Add(LVAddItem(xGroup, "Place Of Birth", .PlaceOfBirth))
            ThisListView.Items.Add(LVAddItem(xGroup, "Community Of Birth", .CommunityOfBirth))
            ThisListView.Items.Add(LVAddItem(xGroup, "State Of Birth", .StateOfBirth))
            ThisListView.Items.Add(LVAddItem(xGroup, "Personal Number", .PersonalNumber))
            ThisListView.Items.Add(LVAddItem(xGroup, "Sex", .Sex))
        End With

    End Sub
    Private Sub SyncDocumentData(ByRef ThisListView As ListView,
                                 ByRef ThisDocumentData As MUPLKLib.cMUPLKDocumentData)

        Dim xGroup As ListViewGroup = New ListViewGroup("dd", "Document Data")

        ' Add Group of items
        ThisListView.Groups.Add(xGroup)

        ' Assign data and append items to ListView
        With ThisDocumentData
            ThisListView.Items.Add(LVAddItem(xGroup, "Issuing Authority", .issuingAuthority))
            ThisListView.Items.Add(LVAddItem(xGroup, "Issuing Date", .issuingDate))
            ThisListView.Items.Add(LVAddItem(xGroup, "Expiry Date", .expiryDate))
            ThisListView.Items.Add(LVAddItem(xGroup, "Reg No.", .docRegNo))
            ThisListView.Items.Add(LVAddItem(xGroup, "Document Type", .documentType))
        End With

    End Sub
    Private Sub SyncVariablePersonalData(ByRef ThisListView As ListView,
                                         ByRef ThisVariablePersonalData As MUPLKLib.cMUPLKVariablePersonalData)

        Dim xGroup As ListViewGroup = New ListViewGroup("vpd", "Variable Personal Data")

        ' Add Group of items
        ThisListView.Groups.Add(xGroup)

        ' Assign data and append items to ListView
        With ThisVariablePersonalData
            ThisListView.Items.Add(LVAddItem(xGroup, "State", .State))
            ThisListView.Items.Add(LVAddItem(xGroup, "Community", .Community))
            ThisListView.Items.Add(LVAddItem(xGroup, "Place", .Place))
            ThisListView.Items.Add(LVAddItem(xGroup, "Street", .Street))
            ThisListView.Items.Add(LVAddItem(xGroup, "House Letter", .HouseLetter))
            ThisListView.Items.Add(LVAddItem(xGroup, "House Number", .HouseNumber))
            ThisListView.Items.Add(LVAddItem(xGroup, "Entrance", .Entrance))
            ThisListView.Items.Add(LVAddItem(xGroup, "Floor", .Floor))
            ThisListView.Items.Add(LVAddItem(xGroup, "Address ApartmentNumber", .ApartmentNumber))
            ThisListView.Items.Add(LVAddItem(xGroup, "Address Label", .AddressLabel))
            ThisListView.Items.Add(LVAddItem(xGroup, "Address Date", .AddressDate))
        End With

    End Sub
    Private Sub SyncPicture(ByRef ThisPictureBox As PictureBox,
                            ByRef ThisLKPicture As MUPLKLib.cMUPLKPicture)

        Try

            ' Get byte array (variant vb6)
            Dim bData() As Byte = ThisLKPicture.PersonPictureB

            ' Load byte array to stream
            Dim xStream As New MemoryStream(bData)

            ' Load picture
            ThisPictureBox.Image = Image.FromStream(xStream)

            ' Dispose stream
            xStream.Dispose()

            ' Free memory resource
            bData = Nothing
            xStream = Nothing

        Catch ex As Exception

            Console.WriteLine("Exception: {0}", ex.ToString)

        End Try

    End Sub
    Private Sub SyncData(ByRef ThisListView As ListView,
                         ByRef ThisPictureBox As PictureBox,
                         ByRef ThisLK As MUPLKLib.cMupLK)

        ' Sync Fixed Personal Data
        SyncFixedPersonalData(ThisListView, ThisLK.FixedPersonalData)

        ' Sync Variable Personal Data
        SyncVariablePersonalData(ThisListView, ThisLK.VariablePersonalData)

        ' Sync Document Data
        SyncDocumentData(ThisListView, ThisLK.DocumentData)

        ' Sync Picture Data
        SyncPicture(ThisPictureBox, ThisLK.Picture)

    End Sub
    Private Sub GUIClear(ByRef ThisListView As ListView,
                         ByRef ThisPictureBox As PictureBox)

        With ThisListView

            ' Disallow multiselect
            .MultiSelect = False

            ' Allow row full select
            .FullRowSelect = True

            ' Clear all items and groups
            .Items.Clear()
            .Groups.Clear()

        End With

        ' Clear image (picture) if is present
        ThisPictureBox.Image = Nothing


    End Sub
    Private Function ReadData() As Integer

        Dim r As Integer = 0
        Dim xLK As MUPLKLib.cMupLK = New MUPLKLib.cMupLK

        ' Reset GUI
        GUIClear(LVData, PicLK)

        ' Try to read data from 'LK'
        r = xLK.ReadData()

        ' If reading success then
        If r = 0 Then

            Console.WriteLine("{0}.ReadData() Reading success.", ClassName)

            ' Sync data
            SyncData(LVData, PicLK, xLK)

        Else

            Console.WriteLine("{0}.ReadData() Reading error.", ClassName)

        End If

        ' Free memory resource
        xLK = Nothing

        Return r

    End Function
    Private Sub MUPLKTestForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ClassName = Me.Name

    End Sub
    Private Sub CmdReadData_Click(sender As Object, e As EventArgs) Handles CmdReadData.Click

        Dim r As Integer = ReadData() ' Try to read data and get return value of that process

        ' If error then
        If r <> 0 Then

            ' Show message
            MsgBox("Proces iscitavanja nije uspesno izvrsen.", MsgBoxStyle.Exclamation, Me.Text)

        End If

    End Sub
    Private Sub CmdClose_Click(sender As Object, e As EventArgs) Handles CmdClose.Click

        ' Close form
        Me.Close()

    End Sub
End Class
